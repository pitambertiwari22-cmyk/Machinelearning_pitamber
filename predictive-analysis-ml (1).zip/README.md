# 🚀 Predictive Analysis Using Machine Learning – Titanic Survival

## 📌 Overview
This project predicts Titanic passenger survival using Logistic Regression and Random Forest models.  
It demonstrates **data preprocessing, model training, evaluation, and dashboard PDF generation**.

---

## 📂 Files
- `predictive_analysis.ipynb` → Main Jupyter Notebook
- `Predictive_Analysis_Dashboard.pdf` → Dashboard PDF (Generated after running notebook)
- `charts/` → Folder containing generated charts

---

## 📊 Results
| Model               | Accuracy |
|----------------------|----------|
| Logistic Regression  | ~0.79    |
| Random Forest        | ~0.83    |

✅ **Random Forest performed better.**

---

## 📈 Features Influencing Survival
- Fare
- Age
- Pclass
- Sex

---

## 🚀 How to Run
1. Install dependencies:  
   ```bash
   pip install pandas numpy matplotlib seaborn scikit-learn fpdf
   ```
2. Run the notebook `predictive_analysis.ipynb`
3. The final **Dashboard PDF** will be saved as `Predictive_Analysis_Dashboard.pdf`

---

## 📌 Author
- CODTECH Internship Project  
- Created by: *Your Name*  
- Duration: *Internship Dates*
